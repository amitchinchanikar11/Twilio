﻿using System;
using Twilio;
using Twilio.Rest.Conversations.V1;
using Twilio.Rest.Conversations.V1.Conversation;

namespace TwilioConversation
{
    class Program
    {
        static void Main(string[] args)
        {
           
            const string accountSid = "ACb23758bd85cf02b88863a6a12a94274d";
            const string authToken = "b38f565aa2870b32341af9fd1cc66eb1";

            TwilioClient.Init(accountSid, authToken);


            //var conversation = ConversationResource.Create(
            //    friendlyName: "My First Conversation"
            //);

            //    var conversationFetch = ConversationResource.Fetch(
            //    pathSid: "CH8a06ec548d444d0d9166e2d0ce33c305"
            //);

            //    var participant = ParticipantResource.Create(
            //    messagingBindingAddress: "+918097361977",
            //    messagingBindingProxyAddress: "+19285827539",
            //    pathConversationSid: "CH8a06ec548d444d0d9166e2d0ce33c305"//conversation.Sid
            //);



            //Console.WriteLine("Conversation Sid = " + conversation.Sid);
            //Console.WriteLine("ChatService Sid = " + conversationFetch.ChatServiceSid);
            //Console.WriteLine("Participant Sid = " + participant.Sid);

            //ConversationResource.Delete(pathSid: "CH6dde00f6541d4361b86e58f8f3be05e8");

        //    var participant = ParticipantResource.Create(
        //    identity: "testPineapple",
        //    pathConversationSid: "CH8a06ec548d444d0d9166e2d0ce33c305"
        //);
            var participant = ParticipantResource.Create(
            identity: "CaptainPrice",
            pathConversationSid: "CH8a06ec548d444d0d9166e2d0ce33c305"
        );

            Console.WriteLine(participant.Sid);
            Console.ReadLine();



        }
    }
}



