﻿// Install the C# / .NET helper library from twilio.com/docs/csharp/install

using System;
using Twilio;
using Twilio.Rest.Api.V2010.Account;


class Program
{
    static void Main(string[] args)
    {
        const string accountSid = "ACb23758bd85cf02b88863a6a12a94274d";
        const string authToken = "b38f565aa2870b32341af9fd1cc66eb1";

        TwilioClient.Init(accountSid, authToken);

        var message = MessageResource.Create(
            body: "Hello GeoFluent Team!",
            from: new Twilio.Types.PhoneNumber("+19285827539"),//Twilio Number
            to: new Twilio.Types.PhoneNumber("+918097361977")//My Personal Number
        );

        Console.WriteLine(message.Sid);
    }
}
