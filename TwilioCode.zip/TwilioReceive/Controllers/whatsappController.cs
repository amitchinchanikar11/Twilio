﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Twilio.AspNet.Common;
using Twilio.AspNet.Core;
using Twilio.TwiML;

namespace TwilioReceive.Controllers
{
    public class whatsappController : TwilioController
    {
        [EnableCors]
        [HttpPost]
        public async Task<TwiMLResult> IndexAsync(SmsRequest incomingMessage)
        {
            var messagingResponse = new MessagingResponse();
            //var translatedMsg = await Translate(incomingMessage.Body);
            var translatedMsg = incomingMessage.Body+""+await Translate();
            messagingResponse.Message(translatedMsg);
            return TwiML(messagingResponse);
        }
        public async Task<string> Translate()
        {
            return "Hello,Amit";
        }

            public async Task<string> Translate(string msg)
        {
            string responseData = "";
            var baseAddress = new Uri("https://lionbridge-geofluent-api-qa.azurewebsites.net/Translation/v3/");

            using (var httpClient = new HttpClient { BaseAddress = baseAddress })
            {
                httpClient.DefaultRequestHeaders.Authorization
                         = new AuthenticationHeaderValue("Bearer", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiI3YWYzMmJmMy01ZWJhLTQ4MGYtYjI1OS1lNjgwYTI4YjI0MWYiLCJpYXQiOjE2MDMyNzQzNjAsImV4cCI6MTYwMzI3NDk2MCwiaXNzIjoiR2VvRmx1ZW50IFNESyB2MyJ9.iU3rfnwBzoNJtnXvGasDYpVWFgMid218ZaorfE_9u_A");
                var query = new Dictionary<string, string>
                {
                    ["text"] = msg,
                    ["to"] = "mr",
                    ["from"] = "en"
                };
                using (var response = await httpClient.GetAsync(QueryHelpers.AddQueryString("Translate", query)))
                {
                    responseData = await response.Content.ReadAsStringAsync();
                }
            }
            JObject rest = JsonConvert.DeserializeObject<dynamic>(responseData);

            JArray obj = JArray.Parse(rest["result"].ToString());
            string translation = "";
            foreach (var object1 in obj)
            {
                translation = Convert.ToString(object1["text"]);
            }
            return translation;
        }
    }
}