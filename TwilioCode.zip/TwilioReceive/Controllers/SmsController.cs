﻿// Code sample for ASP.NET Core on .NET Core
// From command prompt, run:
// dotnet add package Twilio.AspNet.Core

using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Twilio;
using Twilio.AspNet.Common;
using Twilio.AspNet.Core;
using Twilio.Rest.Chat.V1.Service.Channel;
using Twilio.TwiML;

namespace TwilioReceive.Controllers
{
    public class SmsController : TwilioController
    {
        public void Index(SmsRequest incomingMessage)
        {
            const string accountSid = "ACb23758bd85cf02b88863a6a12a94274d";
            const string authToken = "b38f565aa2870b32341af9fd1cc66eb1";

            TwilioClient.Init(accountSid, authToken);

            //var message = MessageResource.Update(
            //    body: "MESSAGE",
            //    pathServiceSid: "ISfa6ae8f806a8414e82ac2827f79a3b6f",
            //    pathChannelSid: "CH8a06ec548d444d0d9166e2d0ce33c305",
            //    pathSid: "testPineapple"
            //   );

            Console.WriteLine(incomingMessage.SmsSid);

            //var messages = MessageResource.Read(
            //    pathServiceSid: "ISfa6ae8f806a8414e82ac2827f79a3b6f",
            //    pathChannelSid: "CH8a06ec548d444d0d9166e2d0ce33c305",
            //    limit: 20
            //);

            //foreach (var record in messages)
            //{
            //    Console.WriteLine(record.Sid);
            //}
            Console.ReadLine();

            //var messagingResponse = new MessagingResponse();
            //incomingMessage.Body += "Hello!";
            //messagingResponse.Message("The copy cat says: " +
            //                          incomingMessage.Body);

        }
    }
}

